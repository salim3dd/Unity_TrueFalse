﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using ArabicSupport;
using UnityEngine.SceneManagement;

public class AllTextFile : MonoBehaviour
{
    public Text TextQU, TextA1, TextA2, TextA3, TextScore, Text_SectionTitle;
    public Image TrueFalse;
    public GameObject Panel_Answer;
    public Button BTN_An1, BTN_An2, BTN_An3;
    private int Score = 0;
    private int Question_Num = 0;
    private int True_Answer = 0;
    string[] Question_list = null;
    void Start()
    {        
        Score = 0;
        Text_SectionTitle.text = ArabicFixer.Fix(StartControl.SectionTitle, false, false);
        Question_list = System.IO.File.ReadAllLines("assets/txt/"+StartControl.Quation_TextFile);
        ListQU();

    }
    private void ListQU() {
        print(Question_list.Length);
        TrueFalse.gameObject.SetActive(false);
       
        if (Question_list != null)
        {
            if (Question_list.Length > Question_Num)
            {
                string[] Qa = Question_list[Question_Num].Split('/');
                Question_Num++;
                print(Qa.Length);
                if (Qa.Length==5)
                {
                    string QU = Qa[0];
                    string An1 = Qa[1];
                    string An2 = Qa[2];
                    string An3 = Qa[3];

                    TextQU.text = QU.Trim();                    
                    FindObjectOfType<TextFixer>().Start();

                    TextA1.text = ArabicFixer.Fix(An1.Trim(), false, false);
                    TextA2.text = ArabicFixer.Fix(An2.Trim(), false, false);
                    TextA3.text = ArabicFixer.Fix(An3.Trim(), false, false);
                    True_Answer = int.Parse(Qa[4].Trim());
                    BTN_An1.interactable=true;
                    BTN_An2.interactable=true;
                    BTN_An3.interactable=true;
                }
            }
            else
            {
                Panel_Answer.gameObject.SetActive(false);
                TextQU.text = ArabicFixer.Fix("انتهت الاسئلة", false, false);                
            }
        }
    }
    public void BTN_1() {
        if (True_Answer == 1)
        {
            ShowTrueFalse("true");
            Score++;
        }
        else {
            ShowTrueFalse("false");
        }
    }
    public void BTN_2()
    {
        if (True_Answer == 2)
        {
            ShowTrueFalse("true");
            Score++;
        }
        else
        {
            ShowTrueFalse("false");
        }
    }
    public void BTN_3()
    {
        if (True_Answer == 3)
        {
            ShowTrueFalse("true");
            Score++;
        }
        else
        {
            ShowTrueFalse("false");
        }
    }

    private void ShowTrueFalse(string img) {
        BTN_An1.interactable = false;
        BTN_An2.interactable = false;
        BTN_An3.interactable = false;

        TrueFalse.gameObject.SetActive(true);
        TrueFalse.GetComponent<Image>().sprite = Resources.Load<Sprite>(img);
        Invoke("ListQU", 3);
    }

    void Update()
    {        
        TextScore.text = ArabicFixer.Fix("الإجابات الصحيحة "+Score.ToString() + " من "+ Question_list.Length, false, false);
    }

    public void GOTO_Start()
    {

        SceneManager.LoadScene("Start");
    }
}
