﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using ArabicSupport;
public class StartControl : MonoBehaviour
{
    public static string Quation_TextFile = "";
    public static string SectionTitle = "";
    public Text Text_Title, Text_BTN_1, Text_BTN_2, Text_BTN_3;

    void Start()
    {
        Text_Title.text = ArabicFixer.Fix("المسابقة الثقافية", false, false);
        Text_BTN_1.text = ArabicFixer.Fix("اسئلة متنوعة", false, false);
        Text_BTN_2.text = ArabicFixer.Fix("أسئلة إسلامية", false, false);
        Text_BTN_3.text = ArabicFixer.Fix("اسئلة جغرافية", false, false);
    }

   
    void Update()
    {
        
    }

    public void BTN_1()
    {
        print("OK");
        Quation_TextFile = "txtfile_1.txt";
        SectionTitle = "أسئلة متنوعة";
        GOTO_Game();
    }
    public void BTN_2()
    {
        Quation_TextFile = "txtfile_2.txt";
        SectionTitle = "أسئلة اسلامية";
        GOTO_Game();
    }
    public void BTN_3()
    {
        Quation_TextFile = "txtfile_3.txt";
        SectionTitle = "أسئلة جغرافية";
        GOTO_Game();
    }

    public void GOTO_Game() {
       
        SceneManager.LoadScene("Game");
    }
}
